package com.example.mooodule;

public class Item {
    private String mainTitle;
    private String limitSell;
    private String mainMeter;
    private String underMeter;


    public Item(String mainTitle, String limitSell, String mainMeter, String underMeter) {
        this.mainTitle = mainTitle;
        this.limitSell = limitSell;
        this.mainMeter = mainMeter;
        this.underMeter = underMeter;
    }



    public String getMainTitle() {
        return mainTitle;
    }

    public void setMainTitle(String mainTitle) {
        this.mainTitle = mainTitle;
    }

    public String getLimitSell() {
        return limitSell;
    }

    public void setLimitSell(String limitSell) {
        this.limitSell = limitSell;
    }

    public String getMainMeter() {
        return mainMeter;
    }

    public void setMaimMeter(String mainMeter) {
        this.mainMeter = mainMeter;
    }

    public String getUnderMeter() {
        return underMeter;
    }

    public void setUnderMeter(String underMeter) {
        this.underMeter = underMeter;
    }
}

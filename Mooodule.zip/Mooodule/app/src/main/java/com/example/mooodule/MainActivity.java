package com.example.mooodule;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Item> itemList;
    private RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        itemList = new ArrayList<>();
        setAdapter();
        setItemList();
    }


    private void setAdapter(){
        Adapter adapter = new Adapter(itemList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);
    }

    private void setItemList(){
        itemList.add(new Item("BTC - USD", "0.0035100 BTC","Limit sell - 10:24","$1.525.00"));
        itemList.add(new Item("BTC - USD", "0.016174 BTC","Limit buy - 10:31","$3.525.00"));
        itemList.add(new Item("BTC - USD", "0.0155100 BTC","Limit sell - 14:50","$3.525.00"));
        itemList.add(new Item("ZEC - BTC", "142.240 ZEC","Limit sell - 10:24","BTC 0.03142.525.00"));
        itemList.add(new Item("ETH - USD", "1.016174 ETH","Limit sell - 10:31","$1.525.00"));
        itemList.add(new Item("BTC - USD", "0.0035100 BTC","Limit sell - 10:24","$1.525.00"));
        itemList.add(new Item("BTC - USD", "0.016174 BTC","Limit buy - 10:31","$3.525.00"));
        itemList.add(new Item("BTC - USD", "0.0155100 BTC","Limit sell - 14:50","$3.525.00"));
        itemList.add(new Item("ZEC - BTC", "142.240 ZEC","Limit sell - 10:24","BTC 0.03142.525.00"));
    }


}
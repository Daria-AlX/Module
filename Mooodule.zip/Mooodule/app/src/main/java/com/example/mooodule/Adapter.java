package com.example.mooodule;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {

    private ArrayList<Item> items;

    public Adapter(ArrayList<Item> items)
    {
        this.items = items;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        private TextView nameText, nameText2, nameText3, nameText4;

        public MyViewHolder(final View itemView){
            super(itemView);
            nameText = itemView.findViewById(R.id.textView);
            nameText2 = itemView.findViewById(R.id.textView2);
            nameText3 = itemView.findViewById(R.id.textView3);
            nameText4 = itemView.findViewById(R.id.textView4);
        }
    }

    @NonNull
    @Override
    public Adapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.MyViewHolder holder, int position) {
        String name = items.get(position).getMainTitle();
        holder.nameText.setText(name);
        String name2 = items.get(position).getLimitSell();
        holder.nameText3.setText(name2);
        String name3 = items.get(position).getMainMeter();
        holder.nameText2.setText(name3);
        String name4 = items.get(position).getUnderMeter();
        holder.nameText4.setText(name4);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
